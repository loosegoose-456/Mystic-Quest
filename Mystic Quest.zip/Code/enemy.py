import pygame
from settings import *
from entity import Entity
from support import *
import torch
import torch.nn as nn

class Enemy(Entity):
    def __init__(self, monster_name, pos, groups, obstacle_sprites, damage_player, trigger_death_particles, add_exp):
        super().__init__(groups)
        self.sprite_type = 'enemy'

        # AI model
        self.last_player_moves = [0, 0, 0, 0, 0]
        self.ai_model = nn.Sequential(
            nn.Linear(5, 32),
            nn.ReLU(),
            nn.Linear(32, 4)
        )
        self.ai_model.load_state_dict(torch.load("enemy_ai_weights.pth"))
        self.ai_model.eval()

        # graphics
        self.import_graphics(monster_name)
        self.status = 'idle'
        self.image = self.animations[self.status][self.frame_index]

        # movement and position
        self.rect = self.image.get_rect(topleft=pos)
        self.hitbox = self.rect.inflate(0, -10)
        self.obstacle_sprites = obstacle_sprites

        # stats
        self.monster_name = monster_name
        monster_info = monster_data[self.monster_name]
        self.health = monster_info['health'] * 1.5
        self.max_health = monster_info['health'] * 1.5
        self.exp = monster_info['exp']
        self.speed = monster_info['speed']
        self.attack_damage = monster_info['damage']
        self.resistance = monster_info['resistance']
        self.attack_radius = monster_info['attack_radius']
        self.notice_radius = monster_info['notice_radius']
        self.attack_type = monster_info['attack_type']

        # interactions
        self.can_attack = True
        self.attack_time = None
        self.attack_cooldown = 400
        self.damage_player = damage_player
        self.trigger_death_particles = trigger_death_particles
        self.add_exp = add_exp

        # invincibility
        self.vulnerable = True
        self.hit_time = None
        self.invincibility_duration = 300

        # sounds
        self.death_sound = pygame.mixer.Sound('../audio/death.wav')
        self.hit_sound = pygame.mixer.Sound('../audio/hit.wav')
        self.attack_sound = pygame.mixer.Sound(monster_info['attack_sound'])
        self.death_sound.set_volume(0.6)
        self.hit_sound.set_volume(0.6)
        self.attack_sound.set_volume(0.6)

        # fleeing behavior
        self.flee_health_threshold = self.max_health * 0.3
        self.fleeing = False
        self.flee_duration = 2000
        self.flee_start_time = None
        self.heal_rate = 0.005 * self.max_health

    def import_graphics(self, name):
        self.animations = {'idle': [], 'move': [], 'attack': []}
        main_path = f'../graphics/monsters/{name}/'
        for animation in self.animations.keys():
            self.animations[animation] = import_folder(main_path + animation)

    def get_player_distance_direction(self, player):
        enemy_vec = pygame.math.Vector2(self.rect.center)
        player_vec = pygame.math.Vector2(player.rect.center)
        distance = (player_vec - enemy_vec).magnitude()
        direction = (player_vec - enemy_vec).normalize() if distance > 0 else pygame.math.Vector2()
        return distance, direction

    def get_status(self, player):
        distance, direction = self.get_player_distance_direction(player)
        current_time = pygame.time.get_ticks()

        if self.health <= self.flee_health_threshold or self.fleeing:
            if not self.fleeing:
                self.fleeing = True
                self.flee_start_time = current_time

            self.status = 'move'
            self.direction = -direction
            self.health = min(self.max_health, self.health + self.heal_rate)

            if (current_time - self.flee_start_time >= self.flee_duration) or (self.health >= self.max_health):
                self.fleeing = False
            return

        if distance <= self.attack_radius and self.can_attack:
            self.status = 'attack'
            self.direction = pygame.math.Vector2()  # stop to attack
        elif distance <= self.notice_radius:
            # 👇 anti-stick: move away if too close
            if distance < TILESIZE * 0.75:
                self.status = 'move'
                self.direction = -direction  # back off a bit
            else:
                self.status = 'move'
                self.direction = direction
        else:
            self.status = 'idle'
            self.direction = pygame.math.Vector2()

    def actions(self, player):
        # Update move history
        if player.direction.y < 0:
            move = 0
        elif player.direction.y > 0:
            move = 1
        elif player.direction.x < 0:
            move = 2
        elif player.direction.x > 0:
            move = 3
        else:
            move = self.last_player_moves[-1]

        self.last_player_moves.pop(0)
        self.last_player_moves.append(move)

        # Predict player's next move
        with torch.no_grad():
            x = torch.tensor([self.last_player_moves], dtype=torch.float32)
            output = self.ai_model(x)
            predicted = torch.argmax(output).item()

        offset = {
            0: (0, -TILESIZE),
            1: (0, TILESIZE),
            2: (-TILESIZE, 0),
            3: (TILESIZE, 0)
        }[predicted]

        predicted_pos = (self.rect.centerx + offset[0], self.rect.centery + offset[1])
        predicted_rect = pygame.Rect(0, 0, TILESIZE, TILESIZE)
        predicted_rect.center = predicted_pos

        player_distance = pygame.math.Vector2(self.hitbox.center).distance_to(player.hitbox.center)

        if self.status == 'attack' and self.can_attack:
            if (
                predicted_rect.colliderect(player.hitbox)
                or self.hitbox.colliderect(player.hitbox)
                or player_distance <= TILESIZE
            ):
                self.attack_time = pygame.time.get_ticks()
                self.attack_sound.play()
                self.can_attack = False
                self.damage_player(self.attack_damage, self.attack_type)
                self.trigger_death_particles(player.rect.center, self.attack_type)

    def animate(self):
        animation = self.animations[self.status]
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            if self.status == 'attack':
                self.can_attack = False
            self.frame_index = 0

        self.image = animation[int(self.frame_index)]
        self.rect = self.image.get_rect(center=self.hitbox.center)

        if not self.vulnerable:
            alpha = self.wave_value()
            self.image.set_alpha(alpha)
        else:
            self.image.set_alpha(255)

    def cooldowns(self):
        current_time = pygame.time.get_ticks()
        if not self.can_attack and current_time - self.attack_time >= self.attack_cooldown:
            self.can_attack = True

        if not self.vulnerable and current_time - self.hit_time >= self.invincibility_duration:
            self.vulnerable = True

    def get_damage(self, player, attack_type):
        if self.vulnerable:
            self.hit_sound.play()
            self.direction = self.get_player_distance_direction(player)[1]
            if attack_type == 'weapon':
                self.health -= player.get_full_weapon_damage()
            else:
                self.health -= player.get_full_magic_damage()
            self.hit_time = pygame.time.get_ticks()
            self.vulnerable = False

    def check_death(self):
        if self.health <= 0:
            self.kill()
            self.trigger_death_particles(self.rect.center, self.monster_name)
            self.add_exp(self.exp)
            self.death_sound.play()

    def hit_reaction(self):
        if not self.vulnerable:
            self.direction *= -self.resistance

    def update(self):
        self.hit_reaction()
        self.move(self.speed)
        self.animate()
        self.cooldowns()
        self.check_death()

    def update_state(self, player):
        self.get_status(player)
        self.actions(player)

    def draw_health_bar(self, surface):
        health_ratio = self.health / self.max_health
        bar_width = 40
        bar_height = 6

        back_bar = pygame.Rect(0, 0, bar_width, bar_height)
        health_bar = pygame.Rect(0, 0, bar_width * health_ratio, bar_height)

        back_bar.midbottom = self.rect.midtop + pygame.math.Vector2(0, -10)
        health_bar.midbottom = self.rect.midtop + pygame.math.Vector2(0, -10)

        pygame.draw.rect(surface, 'darkred', back_bar)
        pygame.draw.rect(surface, 'limegreen', health_bar)
        pygame.draw.rect(surface, 'black', back_bar, 1)

    def draw(self, surface):
        surface.blit(self.image, self.rect.topleft)
        self.draw_health_bar(surface)

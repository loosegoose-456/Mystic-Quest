import torch
import torch.nn as nn
import torch.optim as optim
import random

# Directions: 0 = up, 1 = down, 2 = left, 3 = right
X = []
y = []
for _ in range(1000):
    seq = [random.randint(0, 3) for _ in range(5)]
    X.append(seq)
    y.append(seq[-1])  # predict the last move

X = torch.tensor(X, dtype=torch.float32)
y = torch.tensor(y, dtype=torch.long)

model = nn.Sequential(
    nn.Linear(5, 32),
    nn.ReLU(),
    nn.Linear(32, 4)  # 4 direction classes
)

loss_fn = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

for epoch in range(300):
    optimizer.zero_grad()
    pred = model(X)
    loss = loss_fn(pred, y)
    loss.backward()
    optimizer.step()

torch.save(model.state_dict(), "enemy_ai_weights.pth")
print("Model weights saved to enemy_ai_weights.pth")

import pygame, sys
from settings import *
from level import Level

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGTH))
        pygame.display.set_caption("Mystic Quest")
        self.clock = pygame.time.Clock()

        # game states
        self.game_active = False
        self.show_controls = False
        self.game_paused = False
        self.level = None

        # sound setup
        self.main_sound = pygame.mixer.Sound('../audio/main.ogg')
        self.volume = 0.5
        self.main_sound.set_volume(self.volume)

        # fonts
        self.font = pygame.font.Font(UI_FONT, 60)
        self.small_font = pygame.font.Font(UI_FONT, 30)

        # background
        self.start_bg = pygame.transform.scale(
            pygame.image.load('../graphics/ui/start_bg.png').convert(), 
            (WIDTH, HEIGTH)
        )

        # UI buttons
        self.button_rect = pygame.Rect(WIDTH // 2 - 100, HEIGTH // 2 + 50, 200, 60)
        self.controls_button_rect = pygame.Rect(WIDTH // 2 - 130, HEIGTH // 2 + 130, 260, 60)
        self.back_button_rect = pygame.Rect(WIDTH // 2 - 60, HEIGTH - 100, 120, 40)
        self.resume_button_rect = pygame.Rect(WIDTH // 2 - 100, HEIGTH // 2, 200, 60)
        self.main_menu_button_rect = pygame.Rect(WIDTH // 2 - 120, HEIGTH // 2 + 80, 240, 60)
        self.vol_container_rect = pygame.Rect(WIDTH // 2 - 150, HEIGTH // 2 + 160, 300, 100)
        self.vol_down_rect = pygame.Rect(0, 0, 50, 40)
        self.vol_up_rect = pygame.Rect(0, 0, 50, 40)

    def reset_game(self):
        self.level = Level()
        self.main_sound.stop()
        self.show_controls = False
        self.game_paused = False
        self.game_active = True
        self.main_sound.play(loops=-1)

    def return_to_main_menu(self):
        self.level = None
        self.main_sound.stop()
        self.show_controls = False
        self.game_paused = False
        self.game_active = False

    def draw_controls_screen(self):
        self.screen.blit(self.start_bg, (0, 0))
        title = self.font.render("Controls", True, TEXT_COLOR)
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 60)))

        controls = [
            "Move: W A S D",
            "Switch Weapon: Q",
            "Weapon Attack: F",
            "Switch Magic: E",
            "Magic Attack: Left Shift",
            "Open Upgrade Menu: M",
            "Upgrade Selection: R"
        ]

        for i, line in enumerate(controls):
            text = self.small_font.render(line, True, TEXT_COLOR)
            self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 140 + i * 40))

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.back_button_rect, border_radius=8)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.back_button_rect, 3, border_radius=8)
        back_text = self.small_font.render("Back", True, TEXT_COLOR)
        self.screen.blit(back_text, back_text.get_rect(center=self.back_button_rect.center))

    def draw_start_screen(self):
        self.screen.blit(self.start_bg, (0, 0))
        title = self.font.render("Mystic Quest", True, TEXT_COLOR)
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGTH // 2 - 100)))

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.button_rect, border_radius=8)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.button_rect, 3, border_radius=8)
        start_text = self.small_font.render("Start", True, TEXT_COLOR)
        self.screen.blit(start_text, start_text.get_rect(center=self.button_rect.center))

        self.controls_button_rect.centery = self.button_rect.centery + 90
        pygame.draw.rect(self.screen, UI_BG_COLOR, self.controls_button_rect, border_radius=8)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.controls_button_rect, 3, border_radius=8)
        controls_text = self.small_font.render("Controls", True, TEXT_COLOR)
        self.screen.blit(controls_text, controls_text.get_rect(center=self.controls_button_rect.center))

    def draw_death_screen(self):
        self.screen.blit(self.start_bg, (0, 0))
        death_text = self.font.render("Game Over", True, 'red')
        prompt_text = self.small_font.render("Press any key to respawn", True, TEXT_COLOR)

        self.screen.blit(death_text, death_text.get_rect(center=(WIDTH // 2, HEIGTH // 2 - 40)))
        self.screen.blit(prompt_text, prompt_text.get_rect(center=(WIDTH // 2, HEIGTH // 2 + 20)))

    def draw_pause_screen(self):
        self.screen.blit(self.start_bg, (0, 0))
        title = self.font.render("Paused", True, TEXT_COLOR)
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGTH // 2 - 120)))

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.resume_button_rect, border_radius=8)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.resume_button_rect, 3, border_radius=8)
        resume_text = self.small_font.render("Resume", True, TEXT_COLOR)
        self.screen.blit(resume_text, resume_text.get_rect(center=self.resume_button_rect.center))

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.main_menu_button_rect, border_radius=8)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.main_menu_button_rect, 3, border_radius=8)
        menu_text = self.small_font.render("Main Menu", True, TEXT_COLOR)
        self.screen.blit(menu_text, menu_text.get_rect(center=self.main_menu_button_rect.center))

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.vol_container_rect, border_radius=8)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.vol_container_rect, 3, border_radius=8)

        vol_text = self.small_font.render(f"Volume: {int(self.volume * 100)}%", True, TEXT_COLOR)
        vol_text_rect = vol_text.get_rect(center=(WIDTH // 2, self.vol_container_rect.top + 25))
        self.screen.blit(vol_text, vol_text_rect)

        self.vol_down_rect.center = (WIDTH // 2 - 50, self.vol_container_rect.bottom - 30)
        self.vol_up_rect.center = (WIDTH // 2 + 50, self.vol_container_rect.bottom - 30)

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.vol_down_rect, border_radius=6)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.vol_down_rect, 2, border_radius=6)
        down_text = self.small_font.render("-", True, TEXT_COLOR)
        self.screen.blit(down_text, down_text.get_rect(center=self.vol_down_rect.center))

        pygame.draw.rect(self.screen, UI_BG_COLOR, self.vol_up_rect, border_radius=6)
        pygame.draw.rect(self.screen, UI_BORDER_COLOR, self.vol_up_rect, 2, border_radius=6)
        up_text = self.small_font.render("+", True, TEXT_COLOR)
        self.screen.blit(up_text, up_text.get_rect(center=self.vol_up_rect.center))

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if not self.game_active:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if self.show_controls:
                            if self.back_button_rect.collidepoint(event.pos):
                                self.show_controls = False
                        else:
                            if self.button_rect.collidepoint(event.pos):
                                self.reset_game()
                            elif self.controls_button_rect.collidepoint(event.pos):
                                self.show_controls = True

                elif self.level and self.level.player_dead:
                    if event.type == pygame.KEYDOWN:
                        self.reset_game()

                elif self.game_paused:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if self.resume_button_rect.collidepoint(event.pos):
                            self.game_paused = False
                            self.main_sound.play(loops=-1)
                        elif self.main_menu_button_rect.collidepoint(event.pos):
                            self.return_to_main_menu()
                        elif self.vol_down_rect.collidepoint(event.pos):
                            self.volume = max(0.0, self.volume - 0.1)
                            self.main_sound.set_volume(self.volume)
                        elif self.vol_up_rect.collidepoint(event.pos):
                            self.volume = min(1.0, self.volume + 0.1)
                            self.main_sound.set_volume(self.volume)

                elif self.game_active:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            self.game_paused = True
                            self.main_sound.stop()
                        elif event.key == pygame.K_m:
                            self.level.toggle_menu()

            self.screen.fill(WATER_COLOR)

            if self.game_active:
                if self.level and self.level.player_dead:
                    self.draw_death_screen()
                elif self.game_paused:
                    self.draw_pause_screen()
                else:
                    self.level.run()
            elif self.show_controls:
                self.draw_controls_screen()
            else:
                self.draw_start_screen()

            pygame.display.update()
            self.clock.tick(FPS)

if __name__ == '__main__':
    game = Game()
    game.run()
